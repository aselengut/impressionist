package edu.umd.hcil.impressionistpainter434;

/**
 * Created by jon on 3/23/2016.
 */
public enum BrushType {
    Circle,
    Square,
    Line,
    Splatter
}
